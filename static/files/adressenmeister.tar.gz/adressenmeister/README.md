Adressenmeister
===============

This is my very first software project from 1992 written in BASIC 2.0 on my C64. It was never really finished but had a nice intro screen and was able to print labels on a wire printer. An example for such a print can be seen in /images

Files
-----

* adressenmeister.d64: The full disc image file
* adressenmeister.prg: The original prg-file rescued from a floppy disc
* adressenmeister.bas: A text-converted version of the source code

