#include "callsign.h"

const char CALLSIGN_STRING_PRIVATE [] PROGMEM = "DK1MI";
const char* const CALLSIGN_STRING = CALLSIGN_STRING_PRIVATE;
