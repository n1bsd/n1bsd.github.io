//Include the font so that it's built by the arduino
//default builder, despite being in a subdirectory
//#include "PDQ_MinLib/glcdfont.c"

#include <avr/pgmspace.h>
const unsigned char glcdfont[] PROGMEM = {0};