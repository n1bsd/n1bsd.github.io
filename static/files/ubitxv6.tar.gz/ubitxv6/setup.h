#pragma once

#include "menu.h"

extern Menu_t* const setupMenu;

void setupTouch();
void runLocalOscSetting();
void runBfoSetting();