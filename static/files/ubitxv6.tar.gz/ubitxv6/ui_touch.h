#pragma once

#include "menu.h"
#include "point.h"

ButtonPress_e checkTouch(Point *const touch_point_out);
