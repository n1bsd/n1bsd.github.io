#pragma once

#include <stdint.h>

struct Point {
  int16_t x;
  int16_t y;
};
