#include "version.h"

const char VERSION_STRING_PRIVATE [] PROGMEM = "R1.5.1";
const char* const VERSION_STRING = VERSION_STRING_PRIVATE;