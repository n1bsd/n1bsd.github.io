#ifndef _NANO_FONT
#define _NANO_FONT

#include <stdint.h>
#include "PDQ_MinLib/gfxfont.h"

extern const GFXfont* ubitx_font;

#endif //_NANO_FONT