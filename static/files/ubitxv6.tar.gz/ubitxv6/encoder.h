#pragma once

void enc_setup(void);
int enc_read(void);
