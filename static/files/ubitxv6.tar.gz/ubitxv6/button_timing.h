#pragma once

static const uint8_t DEBOUNCE_DELAY_MS = 50;
static const uint16_t LONG_PRESS_TIME_MS = 3000;
static const uint8_t LONG_PRESS_POLL_TIME_MS = 10;