#pragma once

enum ButtonPress_e : uint8_t {
  NotPressed,
  ShortPress,
  LongPress
};
