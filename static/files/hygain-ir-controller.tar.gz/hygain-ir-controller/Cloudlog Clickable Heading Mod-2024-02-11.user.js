// ==UserScript==
// @name         Cloudlog Clickable Heading Mod
// @namespace    https://dk1mi.radio
// @version      2024-02-11
// @description  Replaces the heading info below the gridsquare field in Clouglog with a clickable link
// @author       DK1MI
// @match        https://*.cloudlog.co.uk/index.php/qso*
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    // Define global variable for base URL
    var API_URL = 'http://192.168.88.155/get?heading=';

    // Function to replace text with link
    function replaceTextWithLink() {
        var locatorInfo = document.getElementById('locator_info');
        if (locatorInfo) {
            var textContent = locatorInfo.textContent.trim();
            var match = textContent.match(/\d+/);
            if (match && match.length > 0) {
                var number = match[0];
                var link = document.createElement('a');
                link.href = API_URL + number; // Construct link using baseURL variable
                link.textContent = textContent;
                locatorInfo.textContent = '';
                locatorInfo.appendChild(link);
            }
        }
    }

    // Initial execution of the function
    replaceTextWithLink();

    // Check for changes periodically
    setInterval(replaceTextWithLink, 1000); // Adjust the interval as needed
})();