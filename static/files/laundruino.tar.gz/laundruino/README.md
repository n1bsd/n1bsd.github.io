laundruino
==========

The Laundruino is a little Arduino project that conects my washing machine to the LAN. You can read more about it here: https://qrz.is/the-arduino-enabled-washing-machine/

