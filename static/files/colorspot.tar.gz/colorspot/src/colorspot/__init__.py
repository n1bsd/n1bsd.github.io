from colorspot.__main__ import ColorSpot

__version__ = '0.1.6'
