# Hardrock 50 Amp remote control via quisk

Original version by Harald Klein, OE6HKE in 2022: https://github.com/haklein/hrctl/

Modified by Michael Clemens, DK1MI in 2024

This project provides a Quisk widget and the corresponding backend daemon to remotely control and read out a Hardrock-50 amp:

* Automatically set the band filters on the HR50 according to the band chosen in Quisk
* Remotely re-tune the Hardrock-50 from within Quisk
* Remotely display power, temperature, VSWR and band of the HR50

## hrctl.py

This Python script can be executed on a single-board computer such as the Raspberry Pi, for example. It acts as a small web server that provides an API via which the above-mentioned parameters can be queried. It is also possible to use this API to send a command via USB to the Hardrock-50 to tell it to re-tune during the next transmit and to set the HR50 to the band chosen in Quisk.

Under Debian Bookworm I had to install the following packages before running the script:

```
# apt install python3-serial python3-gevent-websocket python3-tinyrpc python3-werkzeug
```

The script can then be executed - ideally within a Tmux session - as follows:

```
# python3 ./hrctl.py
```

## hermes_widgets.py

The _hermes_widgets.py_ script is a Quisk widget that displays both the "Tune Hardrock-50" button and the information collected by the Hardrock-50 at the bottom left of the user interface.

![screenshot](screenshot.png)

A click on the "Tune" button sends a command to the backend which then again sends a command to the Hardrock-50 to initiate a re-tune process during the next transmission. 

It furthermore periodically sends the selected band to the backend to automatically set the correct band at the Hardrock-50.

Status won't be updated during transmit as the Hardrock 50 disables serial communication during TX.

To install it, place it anywhere in the file system on the system on which Quisk is to be executed. Afterwards, the following steps must then be carried out within Quisk:

* Click on "Config
* Select Hermes Lite next to "Radios" at the top
* Click on Change to the right of "Widget File Path"
* Select the script
* Restart Quisk

It may also be necessary to install Python libraries here. These are roughly the same as for the web server script.
