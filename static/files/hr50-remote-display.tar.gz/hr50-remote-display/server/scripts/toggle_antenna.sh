#!/usr/bin/bash
eval $(sudo usbrelay 2>/dev/null)
#echo $BITFT_1
if [ $BITFT_1 -eq 0 ]
then
  sudo usbrelay BITFT_1=1 > /dev/null 2>&1
else
  sudo usbrelay BITFT_1=0 > /dev/null 2>&1
fi
eval $(sudo usbrelay 2>/dev/null)
if [ $BITFT_1 -eq 0 ]
then
  echo "Cobweb"
else
  echo "Vertical"
fi
