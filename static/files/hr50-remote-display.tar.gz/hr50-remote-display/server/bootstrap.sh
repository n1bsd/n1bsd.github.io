export FLASK_APP=hr50_rd_server.py
flask run --host=0.0.0.0
