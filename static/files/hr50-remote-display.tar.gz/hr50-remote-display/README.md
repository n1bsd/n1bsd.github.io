# Hardrock-50 Remote Display

The Hardrock-50 is a 50W power amplifier for amateur radio QRP transceivers. It has a display showing valuable information like the selected band, the SWR, power, temperature etc. Since I am using the HR50 in a remote station, I cannot directly access those information via the display.

However, the HR50 offers serial communication via a USB port. This project tries to solve this problem with the help of a separate, wifi enabled hardware display. It consists of the following two components:

* Heltec ESP32 board with display
* a python flask application, which represents the communication via the serial interface in the form of an API

This diagram shows which components are required and how the communicate:

![Diagram](diagram.jpg "Diagram")

This is how the display looks like in action:

![Photo of the Heltec board](hr50-remote-display.jpg "Photo of the Heltec board")

You can find a short video here: [https://www.youtube.com/watch?v=50ZxkoQPq7Y]

# Client

## Preconditions

### Hardware

* Heltec ESP32 Wifi Dev Kit Board with OLED

### Software

* Arduino IDE

### Libraries

* Heltec Libraries: [https://github.com/Heltec-Aaron-Lee/WiFi_Kit_series]
* ArduinoJson
* HTTPClient
* WiFi
* EasyButton

## Configuration

Rename the file _config.h_dist_ to _config.h_ and edit the following lines:

```
const char* ssid = "<ENTER_HERE_YOUR_WIFI_SSID>";
const char* password = "<PASSWORD>";
String api_base_url = "http://<ENTER_HERE_THE_IP_OF_YOUR API_SERVER>:5000";
```

Example: If your wifi is named "hamradio", your wifi password is "hamradio4life" and the IP address of your server is "192.168.1.100", your config should look like this:

```
const char* ssid = "hamradio";
const char* password = "hamradio4life";
String api_base_url = "http://192.168.1.100:5000";
```

## Installation

Add the files to your Arduino IDE, install all necessary libraries, configure the board and USB/serial port, compile the sketch and then upload it.

## Usage

Execute the server (see below) and power up the ESP board. The following user interaction is possible:

* short press of the upper button: executes a shell script / system command / program (Server config parameter 'shell_cmd')
* long press of the upper button: sends a serial commannd to the HR50. The default command will initiate the tuning cycle during the next transmission (Server config parameter 'serial_cmd')
* the lower button reboots the device

## Error handling

* If wifi is unavailable or misconfigured, the device will show "No Wifi!" on the screen
* HTTP Errors will also displayed on the OLED
* When you key up your TRX and therefore the HR50, no serial communication is possible. The latest gathered information will still be displayed on the screen but there will be a "(!)" in the third row as an indicator for this situation.


# Server

# Preconditions

You need a computer connected to the Hardrock-50 via USB, e.g. a Raspberry Pi. This system needs to be able to run Python and has to be connected to your network.

# Configuration

Open the file _hr50_rd_server.py_ and adapt the following lines to your environment regarding the USB connection to the HR50:

```
serial_port = '/dev/ttyUSB0'
baud = 19200
```

Edit the following lines if you want to customize the actions performed when pressing the upper button:

```
shell_cmd = "./scripts/toggle_antenna.sh"
serial_cmd = "hrtu1"
serial_cmd_msg = "Tune"
```

_serial_cmd_msg_ is a message that will be displayed on the screen after executing the _serial_cmd_.


# Execution

Executing this script will spawn a web server running on port 5000. This is not meant for production use and/or public exposure. Anyone able to access this server via the network can alter any settings on your HR50.

Run it as follows:

```
# cd server
# ./bootstrap.sh
```

# API Endpoints

There are two API endpoints available:

#### /exec_serial

This method allows you to send commands to the HR50. The commands can be taken from the HR50 operator's manual and do not require the trailing ";"

#### /exec_shell

This method allows you to execute shell commands on the server

#### /get_status

This method returns all avalable information in JSON

