```
***************************************************************************************
*                             Hermes Lite 2 Interface Box                             *
*                                                                                     *
*    Reads I2C data from the Hermes Lite 2 and a) controls an antenna switch based    *
*    on the selected band and b) sets the correct LPF of the Hardrock 50 Power Amp    *
*                                                                                     *
*        Based on HL2-PA70 by Cesc Gudayol (EA3IGT) Version 3.0.1 from 01/04/2021     *
*                    More info: https://github.com/ea3igt/HL2-PA70                    *
*                                                                                     *
*                        Adapted by Michael Clemens (DK1MI)                           *
*                  More info: https://dk1mi.radio/hl2-hr50-interface                  *
*                                                                                     * 
*                                                                                     *
*           THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND            *
*                                                                                     *
***************************************************************************************
```