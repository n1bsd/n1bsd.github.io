export FLASK_APP=hr50api.py
flask run --host=0.0.0.0
