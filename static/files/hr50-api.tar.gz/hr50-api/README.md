# Hardrock-50 API

The Hardrock-50 is a 50W power amplifier for amateur radio QRP transceivers. It has a display showing valuable information like the selected band, the SWR, power, temperature etc. This project provides an API that can be used to query all relevant information of the HR50 via HTTP. It is also possible to send commands to the HR50 via HTTP, e.g. to change the band or to change the keying method.


# Preconditions

You need a computer connected to the Hardrock-50 via USB, e.g. a Raspberry Pi. This system needs to be able to run Python and has to be connected to your network.

# Installation

Download all files and copy them into a directory on your raspberry pi. alternatively, you can clone the git repository as follows:

```
micha@rpi:~ git clone https://git.qrz.is/clemens/hr50-api.git
```

# Configuration

Open the file _hr50api.py_ and adapt the following lines to your environment:

```
serial_port = '/dev/ttyUSB0'
baud = 19200
```

# Execution

Executing this script will spawn a web server running on port 5000. This is not meant for production use and/or public exposure. Anyone able to access this server via the network can alter any settings on your HR50.

Run it as follows:

```
micha@rpi:~ cd hr50-api
micha@rpi:~/hr50-api$ ./bootstrap.sh 
```

# API Endpoints

There are two API endpoints available:

#### /?cmd=_command_

This method allows you to send commands to the HR50. The commands can be taken from the HR50 operator's manual and do not require the trailing ";"

#### /status

This method returns all avalable information in JSON

# Examples

Now you can access the API e.g. with your (HR50 Remote Display)[https://git.qrz.is/clemens/hr50-remote-display]

For testing or other purposes, you can access the api with trhe help of curl or any webbrowser:


Set the keying method to 'PTT':

```
micha@rpi:~/hr50-api$ curl http://<IP_ADDRESS>:5000?cmd=hrmd1
```

Set the keying method to 'COR':
```
micha@rpi:~/hr50-api$ curl http://<IP_ADDRESS>:5000?cmd=hrmd2
```

Query the status:
```
micha@rpi:~/hr50-api$ curl http://<IP_ADDRESS>:5000/status
{"AVG":"43","BND":"15M","PEP":"60","PTT":"COR","STA":"RX","SWR":"1.9","TMP":"12C","VLT":"13.7V"}
```
