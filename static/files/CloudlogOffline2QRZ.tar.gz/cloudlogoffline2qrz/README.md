# CloudlogOffline2QRZ

API server emulating a [Cloudlog](https://github.com/magicbug/Cloudlog) instance that receives QSOs from [CloudLogOffline](https://github.com/myzinsky/cloudLogOffline) and sends them to a defined QRZ.com logbook.

This enables you to use the fantastic App CloudLogOffline to log QSOs for example with your phone when you are portable and have no cell service. Afterwards you can export all new QSOs via CloudlogOffline2QRZ directly into your QRZ.com logbook. CloudlogOffline2QRZ acts as a middleman by pretendig to be a Cloudlog server, receiving the QSOs and then uploading them via the QRZ.com API to your QRZ logbook. For this you need to execute CloudlogOffline2QRZ for example on a VPS behind a web server.

# Installation

CloudlogOffline2QRZ needs Python 3 and the following libraries:

 * flask
 * flask-restful
 * waitress

Furthermore, you need at least the XML subscription from QRZ.com.

Before installing CloudlogOffline2QRZ, please make sure that the above mentioned libraries have been installed:

```
# python3 -m pip install flask
# python3 -m pip install flask-restful
# python3 -m pip install waitress
```

To download or update qrzlogger, clone the repo:

```
# git clone https://codeberg.org/mclemens/CloudlogOffline2QRZ.git
```

Configure your web server as a reverse proxy to forward requests sent to a certain subdomain or URL to localhost:5000

# Usage

 * execute the application with "python3 CloudlogOffline2QRZ.py"
 * CloudlogOffline2QRZ creates a default config file and states its location (e.g. _~/.config/CloudlogOffline2QRZ/CloudlogOffline2QRZ.ini_)
 * adapt _~/.config/CloudlogOffline2QRZ/CloudlogOffline2QRZ.ini_ to your needs. Important setting are:
    * QRZ.com/station_call: This is your station call (must match with the QRZ.com logbook)
    * QRZ.com/api_key: Your QRZ.com API key. You find it under "settings" in the QRZ.com logbook'
	* general/api_key: A free definable API key. Must be the same as configured in CloudlogOffline
	* general/install_path: Enter here your CloudlogOffline2QRZ path as configured in your web server, e.g. _'/'_ or _'/log/'_
 * execute the application again with "python3 CloudlogOffline2QRZ.py"
 * the software now listens on localhost:5000
 * configure CloudlogOffline:
    * Hostname: The domain your webserver is listening to in order to redirect requests to localhost:5000
	* API Key: same as general/api_key (see above).
	* Station ID: doesn't matter

# License

see ![LICENSE](LICENSE)

